
library(dplyr)
library(rpart)
library(lubridate)
library(ROCR)
library("xgboost")
library(readxl)
library(openxlsx)

options(scipen=999)


##########start############################
library(readxl)
demog = read_excel('C:/Users/dewi.ismardi/Documents/DEWI/DIGITAL/PD MODEL/Implementasi api/CONTOH SLIK DATA/send to idx/IDEB_DATAPOKOKDEBITUR_V.xlsx')
kredit = read_excel('C:/Users/dewi.ismardi/Documents/DEWI/DIGITAL/PD MODEL/Implementasi api/CONTOH SLIK DATA/send to idx/IDEB_KREDIT_V.xlsx')


setwd("C:/Users/dewi.ismardi/Documents/DEWI/DIGITAL/LEAD BASE/PD FOR LEAD BASE/INPUT DATA/SLIK/")
model_xgb = readRDS(file = "C:/Users/dewi.ismardi/Documents/DEWI/DIGITAL/PD MODEL/SLIK SCRIPT/Dev_Hit_model_xgb.RDS")
xgb_importance = read.csv('C:/Users/dewi.ismardi/Documents/DEWI/DIGITAL/PD MODEL/SLIK SCRIPT/xgb_importance_dimred.csv', stringsAsFactors = FALSE)



kredit = kredit[kredit$kondisiKet %in% c("Fasilitas Aktif","FASILITAS AKTIF"),]


demog_unique = demog[,c("resultid","seq","pelapor","noIdentitas")]
demog_unique = demog_unique[!duplicated(demog_unique),]
colnames(demog_unique) = c("resultid","seq_demog","pelapor","noidentitas")

kredit_sample = kredit[kredit$resultid %in% demog_unique$resultid,]
kredit_unique_sample = kredit_sample[!duplicated(kredit_sample[,c("resultid","fasilitasid","ljk")]),]

kredit123= merge(x = kredit_unique_sample, y = demog_unique, all.x = TRUE, 
                 by.x =c('resultid','ljk'), by.y = c('resultid','pelapor'))

#######start
# kredit123 = read.csv('DATA_POKOK_KREDIT_200904_segmentB.csv', stringsAsFactors = FALSE)


kredit123$isCreditCard = ifelse(kredit123$jenisKreditPembiayaan=='30',1,0)
kredit123$isUnsecured = ifelse(kredit123$jenisKreditPembiayaan=='05' &
                                 kredit123$jenisPenggunaan =='3' &
                                 kredit123$sektorEkonomi=='009000',1,0)

# kredit123$ID_NOX = as.character(kredit123$ID_NOX)
# kredit123$custnoX = as.character(kredit123$custnoX)


###pake cara mba umi di polici, ambil yang strong
# kredit123_3 = kredit123[kredit123$match_desc %in% c("Strong"),]
# kredit123_3$ktp = NULL
# duplicatecek = kredit123_3[!duplicated(kredit123_3$custnoX),]
# table(duplicatecek$BatchSLIK)
# HighP2P  LowP2P 
# 348    7515

#table(kredit123_3$kondisiKet)

# kredit123_4 = kredit123_3[kredit123_3$kondisiKet %in% c("Fasilitas Aktif","FASILITAS AKTIF"),]
# duplicatecek23 = kredit123_4[!duplicated(kredit123_4$ID_NOX),]
# table(duplicatecek23$BatchSLIK)
# HighP2P  LowP2P 
# 289    6774 

kredit123_5 = kredit123_4[!duplicated(kredit123_4[,c("resultid","fasilitasid","ljk")]),]
# duplicatecek234 = kredit123_5[!duplicated(kredit123_5$ID_NOX),]
#table(duplicatecek234$batchSLIK)
#10920  20920  30920 280820 
#280    174   2704    188


# cekdatu  = kredit123_3[kredit123_3$reffnumber %in% 'DIG08706310820087',]
# temp = cekdatu[,c("reffnumber","ID_NOX","ktp", "noIdentitas")]

#biro_join2$match_desc


######################################################################
##################################################GET TRADELINE DATA


col_needed   = c('ktp', 'resultid','fasilitasid', 'bcc_date', 'payment_history_start_date','payment_history_end_date','bureau_score',
                 'date_open', 'date_closed','date_reported','date_of_last_payment','bucket_payment_history1', 'collectibility_payment_history1',
                 'high_credit_sanctioned_amount','account_desc','account_desc_derived', 'ownership_type','reporting_member',
                 'cc_petty_bal_thresh','other_loans_petty_bal_thresh','outstanding_balance','past_due_days','over_due_amount','loan_limit',
                 'interest_rate', 'restructure_freq','restructure_reason')


tradeline_df = kredit123_5
tradeline_df$ktp= tradeline_df$noidentitas
tradeline_df$interest_rate=tradeline_df$sukuBungaImbalan
tradeline_df$restructure_freq=tradeline_df$frekuensiRestrukturisasi
tradeline_df$restructure_reason=tradeline_df$restrukturisasiKet


##### get BCC date 
# note :  since no exact date between when the report are pulled, 
#i'll use max between update date (when the bureau update the data) & created date (when reporting member report)
#and max it again per customer and result_id (search ID)

#temp = tradeline_df[,c('resultid','tanggalUpdate','tanggalUpdate2','tanggalUpdate_1','tanggalUpdate_2', 'update_date_format')]

tradeline_df$tanggalUpdate_cek <- as.character(tradeline_df$tanggalUpdate, "%Y-%m-%d")
tradeline_df$update_date_format = as.Date(tradeline_df$tanggalUpdate_cek, "%Y%m%d")
tradeline_df$tanggalUpdate_cek = NULL


tradeline_df$tanggalDibentuk_cek <- as.character(tradeline_df$tanggalDibentuk, "%Y-%m-%d")
tradeline_df$created_date_format = as.Date(tradeline_df$tanggalDibentuk_cek, "%Y%m%d")
tradeline_df$tanggalDibentuk_cek = NULL

tradeline_df$month_year_format = as.Date(paste(tradeline_df$tahun,tradeline_df$bulan,'01',sep = '-'))
tradeline_df$max_date = apply(tradeline_df[,c('update_date_format','created_date_format','month_year_format')],1,max,na.rm = TRUE)

#temp = tradeline_df[,c('resultid','tanggalUpdate','update_date_format','tanggalDibentuk','created_date_format','month_year_format','max_date')]
# cekblank = tradeline_df[is.na(tradeline_df$max_date),]
# 3374132011920004 ktp max date blank

#tradeline_df$max_date[is.na(tradeline_df$max_date)]<- '.'

#get max date per customer - result id

library(data.table)
bcc_df = setDT(tradeline_df)[,list(
  bcc_date = max(max_date, na.rm = TRUE)
), by=c('noidentitas','resultid')]

#remove duplicate record that have the same cust_id, bcc_date
bcc_df2 = bcc_df[!duplicated(bcc_df[,c('noidentitas','bcc_date')]),]

#cekdouble= tradeline_df[tradeline_df$ID_NOX %in% bcc_df2$ID_NOX,]

tradeline_df= merge(x = tradeline_df, y = bcc_df2, all.x = TRUE, by=c('noidentitas','resultid'))

#temp = tradeline_df[,c('resultid','resultid5','resultid4','resultid3','custnoX','ID_NOX')]

#cekblNK=tradeline_df[is.na(tradeline_df$bcc_date)]

#cekclnk2 = tradeline_df[tradeline_df$custnoX %in% '1958086',]

#remove duplicate search that have the same bcc_date and custid (KTP)
tradeline_df2=tradeline_df[!is.na(tradeline_df$bcc_date)]


######

tradeline_df$payment_history_start_date = as.Date(paste(tradeline_df$tahunBulan24,'01',sep = ''), "%Y%m%d")
tradeline_df$payment_history_end_date = as.Date(paste(tradeline_df$tahunBulan01,'01',sep = ''), "%Y%m%d")
tradeline_df$bureau_score = NA #no data

tradeline_df$tanggalMulai_cek <- as.character(tradeline_df$tanggalMulai, "%Y-%m-%d")
tradeline_df$date_open = as.Date(tradeline_df$tanggalMulai_cek, "%Y%m%d")
tradeline_df$tanggalMulai_cek = NULL

tradeline_df$tanggalJatuhTempo_cek <- as.character(tradeline_df$tanggalJatuhTempo, "%Y-%m-%d")
tradeline_df$date_closed = as.Date(tradeline_df$tanggalJatuhTempo_cek, "%Y%m%d")
tradeline_df$tanggalJatuhTempo_cek = NULL

tradeline_df$date_reported = apply(tradeline_df[,c('update_date_format','created_date_format')],1,max,na.rm = TRUE)
#cekblank = tradeline_df[is.na(tradeline_df$date_reported),]

#tradeline_df$date_reported[is.na(tradeline_df$date_reported)]<- '.'

tradeline_df$date_of_last_payment = NA  #no data

tradeline_df$bucket_payment_history1=''
tradeline_df$collectibility_payment_history1=''

tradeline_df_ori = tradeline_df
#cekdatu  = tradeline_df[tradeline_df$ID_NOX %in% '1050143004815001',]

for (i in 13:24)
{
  strkol = as.character(i)
  if(i<10)
  {
    strkol=paste('0',i, sep = '')
  }
  
  source_kol = paste('tahunBulan',strkol,'Ht',sep = '')
  dest_kol = paste('tahunBulan',strkol,'bucket', sep = '')
  kol_kol =  paste('tahunBulan',strkol,'Kol', sep = '')
  print(source_kol)
  tradeline_df[[source_kol]] = as.numeric(tradeline_df[[source_kol]])
  tradeline_df[[dest_kol]] = ifelse(tradeline_df[[source_kol]]>180,'7',
                                    ifelse(tradeline_df[[source_kol]]>120,'6',
                                           ifelse(tradeline_df[[source_kol]]>90,'5',
                                                  ifelse(tradeline_df[[source_kol]]>60,'4',
                                                         ifelse(tradeline_df[[source_kol]]>30,'3',
                                                                ifelse(tradeline_df[[source_kol]]>0,'2',
                                                                       ifelse(tradeline_df[[source_kol]]==0,'1','X')))))))
  tradeline_df[[kol_kol]][is.na(tradeline_df[[kol_kol]])]='X'
  tradeline_df[[dest_kol]][is.na(tradeline_df[[dest_kol]])]='X'
  tradeline_df[[kol_kol]]=as.character(tradeline_df[[kol_kol]])
  tradeline_df$bucket_payment_history1=paste(tradeline_df$bucket_payment_history1,tradeline_df[[dest_kol]], sep = '')
  tradeline_df$collectibility_payment_history1=paste(tradeline_df$collectibility_payment_history1,tradeline_df[[kol_kol]], sep = '')
  
}

# temp = tradeline_df[,c('plafon','plafonAwal','ID_NOX')]

#table(tradeline_df$plafon)

tradeline_df$max_platfon = apply(tradeline_df[,c('plafonAwal','plafon')],1,max,na.rm = TRUE)

library(data.table)
high_limit_df = setDT(tradeline_df)[,list(
  high_credit_sanctioned_amount = max(max_platfon, na.rm = TRUE)
), by=c('noidentitas','resultid')]

tradeline_df= merge(x = tradeline_df, y = high_limit_df, all.x = TRUE, by=c('noidentitas','resultid'))


tradeline_df$ljkket_upper = toupper(tradeline_df$ljkKet)

tradeline_df$account_desc= ifelse(tradeline_df$jenisKreditPembiayaan=='30','Credit Card',
                                  ifelse(tradeline_df$jenisKreditPembiayaan=='05' & tradeline_df$jenisPenggunaan =='3' & tradeline_df$sektorEkonomi=='009000','Unsecured Loan',
                                         ifelse(tradeline_df$jenisKreditPembiayaan=='05' & tradeline_df$sektorEkonomi %in% c('001100','001110','001120','001130','001210','001220','001230','001300'),'Mortgage Loan',
                                                ifelse(tradeline_df$jenisKreditPembiayaan=='05' & tradeline_df$sektorEkonomi %in% c('004120','004130','004140','004150','004160','004180','004190','004900'),'Multi Purpose Loan',
                                                       ifelse(tradeline_df$jenisKreditPembiayaan %in% c('10','20') & tradeline_df$sektorEkonomi %in% c('002100','002200','002300','002900'),'Auto Loan - Joint Finance, Multifinance',
                                                              ifelse(tradeline_df$jenisKreditPembiayaan=='05' & tradeline_df$sektorEkonomi %in% c('002100','002200','002300','002900'),'Auto Loan',
                                                                     ifelse(tradeline_df$jenisKreditPembiayaan=='80','Current Account Loan',
                                                                            ifelse(tradeline_df$jenisKreditPembiayaan %in% c('10','20'),'Other Multifinance Loan',
                                                                                   ifelse(grepl("BANK", tradeline_df$ljkket_upper)==FALSE,'Other Multifinance Loan',
                                                                                          ifelse(tradeline_df$jenisPenggunaan=='1','Other Working Capita Loan',
                                                                                                 ifelse(tradeline_df$jenisPenggunaan=='2','Other Investment Loan',"Other Loan")))))))))))

# tradeline_df$account_desc_derived = NA 
tradeline_df$account_desc_derived = ifelse(tradeline_df$account_desc=='Credit Card','Credit Card',
                                           ifelse(tradeline_df$account_desc=='Unsecured Loan','Unsecured Loan',
                                                  ifelse(tradeline_df$account_desc=='Mortgage Loan','Secured Loan',
                                                         ifelse(tradeline_df$account_desc=='Multi Purpose Loan','Secured Loan',
                                                                ifelse(tradeline_df$account_desc=='Auto Loan - Joint Finance, Multifinance','Secured Loan',
                                                                       ifelse(tradeline_df$account_desc=='Auto Loan','Secured Loan',
                                                                              ifelse(tradeline_df$account_desc=='Current Account Loan','Other Working Capita Loan',tradeline_df$account_desc)))))))

# cekdatu  = tradeline_df[tradeline_df$ID_NOX %in% '1050143004815001',]


library(data.table)
test = setDT(tradeline_df)[,list(
  counts = .N
), by=c('account_desc_derived','account_desc')]


table(tradeline_df$kategoriDebiturKet)
tradeline_df$kategoridebiturket_upper = toupper(tradeline_df$kategoriDebiturKet)
tradeline_df$kategoridebiturket_upper =gsub('â�,��???O','-',tradeline_df$kategoridebiturket_upper)

library(data.table)
test = setDT(tradeline_df)[,list(
  counts = .N
), by=c('kategoridebiturket_upper')]


tradeline_df$ownership_type = tradeline_df$kategoridebiturket_upper #No data as requested, putting debitor categry for now
tradeline_df$reporting_member = tradeline_df$ljkket_upper
tradeline_df$cc_petty_bal_thresh =NA
tradeline_df$other_loans_petty_bal_thresh=NA
tradeline_df$outstanding_balance = tradeline_df$outstandingPrincipal
tradeline_df$over_due_amount = as.numeric(tradeline_df$tunggakanBunga)+as.numeric(tradeline_df$tunggakanPokok)+as.numeric(tradeline_df$denda)
tradeline_df$past_due_days = tradeline_df$jumlahHariTunggakan
tradeline_df$loan_limit = tradeline_df$plafon
# temp = tradeline_df[, c('tunggakanbunga','tunggakanpokok','denda','over_due_amount')]

#make payment calendar from column to row
#cekdatu  = tradeline_df[tradeline_df$ID_NOX %in% '1050143004815001',]

# col_date = c('ktp','resultid','fasilitasid',
#              'tahunbulan01','tahunbulan02','tahunbulan03','tahunbulan04','tahunbulan05','tahunbulan06','tahunbulan07','tahunbulan08','tahunbulan09','tahunbulan10','tahunbulan11','tahunbulan12',
#              'tahunbulan01ht','tahunbulan02ht','tahunbulan03ht','tahunbulan04ht','tahunbulan05ht','tahunbulan06ht','tahunbulan07ht','tahunbulan08ht','tahunbulan09ht','tahunbulan10ht','tahunbulan11ht','tahunbulan12ht',
#              'tahunbulan01kol','tahunbulan02kol','tahunbulan03kol','tahunbulan04kol','tahunbulan05kol','tahunbulan06kol','tahunbulan07kol','tahunbulan08kol','tahunbulan09kol','tahunbulan10kol','tahunbulan11kol','tahunbulan12kol',
#              'tahunbulan01bucket','tahunbulan02bucket','tahunbulan03bucket','tahunbulan04bucket','tahunbulan05bucket','tahunbulan06bucket','tahunbulan07bucket','tahunbulan08bucket','tahunbulan09bucket','tahunbulan10bucket','tahunbulan11bucket','tahunbulan12bucket')
# 
# pc = tradeline_df[,..col_date]
# # pc = pc[pc$fasilitasid =='3C6E65EA-1B69-4290-9EF1-1A65400EDF21',]
# 
# library(reshape2)
# pc_melt = reshape(pc, idvar  = c('ktp','resultid','fasilitasid'), direction = 'long', 
#                   varying = list(c('tahunbulan01','tahunbulan02','tahunbulan03','tahunbulan04','tahunbulan05','tahunbulan06','tahunbulan07','tahunbulan08','tahunbulan09','tahunbulan10','tahunbulan11','tahunbulan12'),
#                                  c('tahunbulan01ht','tahunbulan02ht','tahunbulan03ht','tahunbulan04ht','tahunbulan05ht','tahunbulan06ht','tahunbulan07ht','tahunbulan08ht','tahunbulan09ht','tahunbulan10ht','tahunbulan11ht','tahunbulan12ht'),
#                                  c('tahunbulan01kol','tahunbulan02kol','tahunbulan03kol','tahunbulan04kol','tahunbulan05kol','tahunbulan06kol','tahunbulan07kol','tahunbulan08kol','tahunbulan09kol','tahunbulan10kol','tahunbulan11kol','tahunbulan12kol'),
#                                  c('tahunbulan01bucket','tahunbulan02bucket','tahunbulan03bucket','tahunbulan04bucket','tahunbulan05bucket','tahunbulan06bucket','tahunbulan07bucket','tahunbulan08bucket','tahunbulan09bucket','tahunbulan10bucket','tahunbulan11bucket','tahunbulan12bucket')),
#                   v.names = c('date','past_due_days','collectibility','bucket'))
# 
# pc_melt = reshape(pc, idvar  = c('ktp','resultid','fasilitasid'), direction = 'long', 
#                   varying = list(c('tahunbulan01','tahunbulan02','tahunbulan03','tahunbulan04','tahunbulan05','tahunbulan06','tahunbulan07','tahunbulan08','tahunbulan09','tahunbulan10','tahunbulan11','tahunbulan12')),
#                   v.names = c('date'))

#table(tradeline_df$ID_NOX)

#temp = tradeline_df[, c("ktp", "ID_NOX")]

final_tradeline = tradeline_df[, ..col_needed]
final_tradeline = final_tradeline[!is.na(final_tradeline$ktp),]

#ada double 
#cekcekcek = final_tradeline[duplicated(final_tradeline[,c("ktp","resultid","fasilitasid")]),]
#cekcekcek2 = final_tradeline[final_tradeline$fasilitasid  %in% 'A3314881-9DD4-42D4-950F-166860D535AB',]

final_tradeline = final_tradeline[!duplicated(final_tradeline[,c("ktp","resultid","fasilitasid")]),]

#table(tradeline_df$account_desc)
#table(final_tradeline$account_desc)

final_tradeline$period2 <- as.character(final_tradeline$period, "%Y-%m-%d")
final_tradeline$period3 = as.Date(final_tradeline$period2, "%Y%m%d")
final_tradeline$period2 = NULL
final_tradeline$period = NULL

final_tradeline$reference_date = final_tradeline$period3

#cekcek = tradeline_df[tradeline_df$resultid %in% 'A01F911D-12DD-46F6-B947-D666F7E79BB9',]
#cekcek2 = final_tradeline[final_tradeline$resultid %in% 'A01F911D-12DD-46F6-B947-D666F7E79BB9',]


#length(unique(final_tradeline$ktp))
#dbWriteTable(con, tolower('fn_slik_tradeline_db_20200502'),
  #           final_tradeline, overwrite=TRUE, row.names=FALSE)



################################### add reference date and choose closest before ########################################


##################################################
###################### FEATURE ENGINERING
##################################################




Tradeline_data <-  final_tradeline 


# Loading required libraries

library(data.table)
library(lubridate)
library(dplyr)

#FINA : FIXING Col name
Tradeline_data$CRN = Tradeline_data$ktp
Tradeline_data$Bureau_score = 0 # no datab assume 0
Tradeline_data$DATE_OPENED = Tradeline_data$date_open
Tradeline_data$DATE_CLOSED = Tradeline_data$date_closed
Tradeline_data$Reference_date = Tradeline_data$reference_date
Tradeline_data$DateReported_trades = Tradeline_data$date_reported
Tradeline_data$PaymentHistoryStartDate = Tradeline_data$payment_history_start_date
Tradeline_data$PaymentHistoryEndDate = Tradeline_data$payment_history_end_date
Tradeline_data$PaymentHistory1 = Tradeline_data$bucket_payment_history1
Tradeline_data$HighCreditSanctionedAmount = Tradeline_data$high_credit_sanctioned_amount
Tradeline_data$Ownership_type =1 # no data. assume 1
Tradeline_data$ACCOUNT_DESC =  Tradeline_data$account_desc
Tradeline_data$CC_petty_bal_thresh=300000
Tradeline_data$Other_loans_petty_bal_thresh = 300000
Tradeline_data$BCC_DATE = Tradeline_data$bcc_date
Tradeline_data$ReportingMemberShortName = Tradeline_data$reporting_member
Tradeline_data$Over_due_amount = Tradeline_data$over_due_amount
Tradeline_data$Out_standing_Balance = Tradeline_data$outstanding_balance
Tradeline_data$interest_rate = as.numeric(Tradeline_data$interest_rate)

Tradeline_data$typeofcreditor = ifelse(grepl("BANK", Tradeline_data$reporting_member)==TRUE,"BANKS",
                                       ifelse(grepl("BPR", Tradeline_data$reporting_member)==TRUE,"BPR","Others"))

Tradeline_data$worstDPDBucket = ifelse(grepl("7", Tradeline_data$bucket_payment_history1)==TRUE,7,
                                       ifelse(grepl("6", Tradeline_data$bucket_payment_history1)==TRUE,6,
                                              ifelse(grepl("5", Tradeline_data$bucket_payment_history1)==TRUE,5,
                                                     ifelse(grepl("4", Tradeline_data$bucket_payment_history1)==TRUE,4,
                                                            ifelse(grepl("3", Tradeline_data$bucket_payment_history1)==TRUE,3,
                                                                   ifelse(grepl("2", Tradeline_data$bucket_payment_history1)==TRUE,2,1))))))


Tradeline_data$resturcture_flag = as.numeric(Tradeline_data$restructure_freq)
Tradeline_data$isInternalReportingMember = ifelse(Tradeline_data$reporting_member %in% c("BANK OCBC NISP","BANK OCBC NISP SYARIAH (UUS)"),1,0)


Business_Loan1 <- c("Other Working Capita Loan","Current Account Loan","Multi Purpose Loan")
Agriculture_Loan1 <- c()
Auto_Loan1 <- c("Auto Loan","Auto Loan - Joint Finance, Multifinance")
Credit_card1 <- c("Credit Card")
Housing_Loan1 <- c("Mortgage Loan")
Personal_Loan1 <- c("Unsecured Loan")
Short_Term_Secured_Loan1 <- c()
Others1 <- c("Other Investment Loan","Other Loan","Other Multifinance Loan") #NOT SURE



Define_loan_types <-function(a,b,c,d,e,f,g,h){
  
  Business_Loan <<- a
  Agriculture_Loan <<- b
  Auto_Loan <<- c
  Credit_card <<- d
  Housing_Loan <<- e
  Personal_Loan <<- f
  Short_Term_Secured_Loan <<- g
  Others <<- h
  
  
}



Define_loan_types(Business_Loan1,Agriculture_Loan1,Auto_Loan1,Credit_card1,Housing_Loan1,Personal_Loan1,Short_Term_Secured_Loan1,Others1)

# Defining Reporting Member type- to be used for classifying it as Internal/ External
# Please pass string array to function 'Define_reporting_member_type' to define bucket for classifying reporting member as internal

Define_reporting_member_type <-function(x){
  Internal <<- x
}

Internal_bank_list <- c("BANK OCBC NISP","BANK OCBC NISP SYARIAH (UUS)")
Define_reporting_member_type(Internal_bank_list)


#Defining formats
Tradeline_data <- as.data.frame(Tradeline_data)
Tradeline_data$CRN <- as.character(Tradeline_data$CRN)


#Deduping on CRN,BCC date & reference date- data_uniqueCRN_ref_BCC_date
data_uniqueCRN_ref_BCC_date<- Tradeline_data[!duplicated(Tradeline_data[,c("CRN","Reference_date","BCC_DATE")]),]
data_uniqueCRN_ref_BCC_date <- data.table(data_uniqueCRN_ref_BCC_date)
# Sorting based on CRN and BCC date
data_uniqueCRN_ref_BCC_date <- data_uniqueCRN_ref_BCC_date[order(data_uniqueCRN_ref_BCC_date$CRN,-data_uniqueCRN_ref_BCC_date$BCC_DATE),]
# Only retaining data with BCC_date < Reference date
data_uniqueCRN_ref_BCC_date <- data_uniqueCRN_ref_BCC_date[data_uniqueCRN_ref_BCC_date$Reference_date>data_uniqueCRN_ref_BCC_date$BCC_DATE,c("CRN","Reference_date","BCC_DATE") ]


Tradeline_data2 <- merge(Tradeline_data,data_uniqueCRN_ref_BCC_date[,c("CRN","BCC_DATE")],by=c("CRN","BCC_DATE"))

# Deduping the trades based on CRN, Loan type, Date opened, Highest Credit sanction amount 
Tradeline_data2<-arrange(Tradeline_data2,CRN,Ownership_type,ACCOUNT_DESC,DATE_OPENED,HighCreditSanctionedAmount,desc(DateReported_trades))
Tradeline_data2<-Tradeline_data2[!duplicated(Tradeline_data2[c("CRN","ACCOUNT_DESC","DATE_OPENED","HighCreditSanctionedAmount")]),]



#---------------------------------      2. FEATURE ENGINEERING- CREATING DPD HISTORY VARIABLES    --------------------------------------------------

# 
feature_engineering_DPD_variables <- function(Data_tradeline){
  
  Tradeline_data2 <- Data_tradeline
  Tradeline_data2 <- as.data.frame(Tradeline_data2)
 
  
  ## Creating DPD flags for 5+, 30+, 60+, 90+ DPD ever
  # Creating flags
  #90+ dpd bucket 5
  Tradeline_data2$index_90_plus =13 - regexpr('5',Tradeline_data2$bucket_payment_history1)
  Tradeline_data2$index_90_plus = ifelse(Tradeline_data2$index_90_plus==14, -1,Tradeline_data2$index_90_plus)
  Tradeline_data2$delq_90_plus_flag = ifelse(Tradeline_data2$index_90_plus==-1, "",1)
  temp=Tradeline_data2[,c('bucket_payment_history1','index_90_plus','delq_90_plus_flag')]
  #60+ dpd bucket 4
  Tradeline_data2$index_60_plus =13 - regexpr('4',Tradeline_data2$bucket_payment_history1)
  Tradeline_data2$index_60_plus = ifelse(Tradeline_data2$index_60_plus==14, -1,Tradeline_data2$index_60_plus)
  Tradeline_data2$delq_60_plus_flag = ifelse(Tradeline_data2$index_60_plus==-1, "",1)
  temp=Tradeline_data2[,c('bucket_payment_history1','index_60_plus','delq_60_plus_flag')]
  #30+ dpd bucket 3
  Tradeline_data2$index_30_plus =13 - regexpr('3',Tradeline_data2$bucket_payment_history1)
  Tradeline_data2$index_30_plus = ifelse(Tradeline_data2$index_30_plus==14, -1,Tradeline_data2$index_30_plus)
  Tradeline_data2$delq_30_plus_flag = ifelse(Tradeline_data2$index_30_plus==-1, "",1)
  temp=Tradeline_data2[,c('bucket_payment_history1','index_30_plus','delq_30_plus_flag')]
  #index_5_plus = assume 1+ dpd bucket 2
  Tradeline_data2$index_5_plus =13 - regexpr('2',Tradeline_data2$bucket_payment_history1)
  Tradeline_data2$index_5_plus = ifelse(Tradeline_data2$index_5_plus==14, -1,Tradeline_data2$index_5_plus)
  Tradeline_data2$delq_5_plus_flag = ifelse(Tradeline_data2$index_5_plus==-1, "",1)
  temp=Tradeline_data2[,c('bucket_payment_history1','index_5_plus','delq_5_plus_flag')]
  
  #Creating delinquency flag -> Anyone who has gone either 5+DPD,or 30+DPD,or 60+DPD,or 90+DPD ever- is tagged as delinquent
  
  Tradeline_data2$delq_flag<-ifelse(is.na(as.numeric(apply(Tradeline_data2[,c("delq_5_plus_flag","delq_30_plus_flag","delq_60_plus_flag","delq_90_plus_flag")],1,max))),0,1)
  
  Tradeline_data2$delq_dt_90_plus<-ifelse(Tradeline_data2$delq_90_plus_flag=="",
                                          "",
                                          ifelse(Tradeline_data2$index_90_plus==1,
                                                 as.character(Tradeline_data2$PaymentHistoryStartDate),
                                                 as.character(ymd(as.Date(Tradeline_data2$PaymentHistoryStartDate,"%Y-%m-%d"))-((as.numeric(Tradeline_data2$index_90_plus)-1)*30))))
  Tradeline_data2$delq_dt_60_plus<-ifelse(Tradeline_data2$delq_60_plus_flag=="",
                                          "",
                                          ifelse(Tradeline_data2$index_60_plus==1,
                                                 as.character(Tradeline_data2$PaymentHistoryStartDate),
                                                 as.character(ymd(as.Date(Tradeline_data2$PaymentHistoryStartDate,"%Y-%m-%d"))-((as.numeric(Tradeline_data2$index_60_plus)-1)*30))))
  Tradeline_data2$delq_dt_30_plus<-ifelse(Tradeline_data2$delq_30_plus_flag=="",
                                          "",
                                          ifelse(Tradeline_data2$index_30_plus==1,
                                                 as.character(Tradeline_data2$PaymentHistoryStartDate),
                                                 as.character(ymd(as.Date(Tradeline_data2$PaymentHistoryStartDate,"%Y-%m-%d"))-((as.numeric(Tradeline_data2$index_30_plus)-1)*30))))
  Tradeline_data2$delq_dt_5_plus<-ifelse(Tradeline_data2$delq_5_plus_flag=="",
                                         "",
                                         ifelse(Tradeline_data2$index_5_plus==1,
                                                as.character(Tradeline_data2$PaymentHistoryStartDate),
                                                as.character(ymd(as.Date(Tradeline_data2$PaymentHistoryStartDate,"%Y-%m-%d"))-((as.numeric(Tradeline_data2$index_5_plus)-1)*30))))
  
  temp=Tradeline_data2[,c('bucket_payment_history1','delq_flag','PaymentHistoryStartDate','index_5_plus','delq_dt_90_plus')]
  
  # Missing value imputation for DATE_OPENED {
  
  Tradeline_data2_null_opened_dt <- Tradeline_data2[is.na(Tradeline_data2$DATE_OPENED),] # Null trade open date
  
  # If DATE_OPENED is null, but PaymentHistoryEndDate is not null, impute DATE_OPENED with PaymentHistoryEndDate, otherwise by DateReported
  Tradeline_data2_null_opened_dt$DATE_OPENED<-as.Date(ifelse(is.na(Tradeline_data2_null_opened_dt$PaymentHistoryEndDate),
                                                             Tradeline_data2_null_opened_dt$DateReported,
                                                             Tradeline_data2_null_opened_dt$PaymentHistoryEndDate),"%Y-%m-%d",origin = "1970-01-01")
  
  Tradeline_data2_not_null_opened_dt <- Tradeline_data2[!is.na(Tradeline_data2$DATE_OPENED),]
  Tradeline_data2<- rbind(Tradeline_data2_null_opened_dt,Tradeline_data2_not_null_opened_dt) #Merging to get all records with mon null DATE_OPENED
  
  #                                           }
  
  #Finding difference between Reference_date and DATE_OPENED
  Tradeline_data2$diff_open_dt <- round(as.numeric(difftime(Tradeline_data2$Reference_date,Tradeline_data2$DATE_OPENED,units = "days")))
  
  # Tradeline_data2$diff_open_dt <-ifelse(is.na(Tradeline_data2$DATE_OPENED), 999999,
  #                          round(as.numeric(difftime(Tradeline_data2$Reference_date,Tradeline_data2$DATE_OPENED,units = "days"))))
  
  
  
  ## Difference between the reference date and delinquency dates
  
  Tradeline_data2$diff_delq_90_plus_dt <- ifelse(Tradeline_data2$delq_dt_90_plus == ""|is.na(Tradeline_data2$delq_dt_90_plus),999999,round(as.numeric(difftime(Tradeline_data2$Reference_date,as.Date(Tradeline_data2$delq_dt_90_plus,"%Y-%m-%d"),units = "days"))))
  Tradeline_data2$diff_delq_60_plus_dt <- ifelse(Tradeline_data2$delq_dt_60_plus == ""|is.na(Tradeline_data2$delq_dt_60_plus),999999,round(as.numeric(difftime(Tradeline_data2$Reference_date,as.Date(Tradeline_data2$delq_dt_60_plus,"%Y-%m-%d"),units = "days"))))
  Tradeline_data2$diff_delq_30_plus_dt <- ifelse(Tradeline_data2$delq_dt_30_plus == ""|is.na(Tradeline_data2$delq_dt_30_plus),999999,round(as.numeric(difftime(Tradeline_data2$Reference_date,as.Date(Tradeline_data2$delq_dt_30_plus,"%Y-%m-%d"),units = "days"))))
  Tradeline_data2$diff_delq_5_plus_dt <- ifelse(Tradeline_data2$delq_dt_5_plus == ""|is.na(Tradeline_data2$delq_dt_5_plus),999999,round(as.numeric(difftime(Tradeline_data2$Reference_date,as.Date(Tradeline_data2$delq_dt_5_plus,"%Y-%m-%d"),units = "days"))))
  
  ## Creating variable max_dt in order to identifying the last payment date as maximum of "DateOfLastPayment","PaymentHistoryStartDate","DateReported"
  Tradeline_data2$DateOfLastPayment = Tradeline_data2$PaymentHistoryStartDate
  Tradeline_data2$max_dt <- apply(Tradeline_data2[,c("DateOfLastPayment","PaymentHistoryStartDate","DateReported_trades")],1,max)
  
  
  ## Clubbing individual account descriptions to the buckets defined in the beginning & tagging Reporting Member as internal/external  {
  
  Tradeline_data2$ACCOUNT_DESC <-iconv(Tradeline_data2$ACCOUNT_DESC,"ASCII",sub="")
  
  Tradeline_data2$ACCOUNT_DESC_derived <- ifelse((Tradeline_data2$ACCOUNT_DESC %in% Business_Loan),as.character("Business Loan"),
                                                 ifelse((Tradeline_data2$ACCOUNT_DESC %in% Agriculture_Loan),as.character("Agriculture Loan"),
                                                        ifelse((Tradeline_data2$ACCOUNT_DESC %in% Auto_Loan),as.character("Auto Loan"),
                                                               ifelse((Tradeline_data2$ACCOUNT_DESC %in% Credit_card),as.character("Credit Card"),
                                                                      ifelse((Tradeline_data2$ACCOUNT_DESC %in% Housing_Loan),as.character("Housing Loan"),
                                                                             ifelse((Tradeline_data2$ACCOUNT_DESC %in% Others),as.character("Other"),
                                                                                    ifelse((Tradeline_data2$ACCOUNT_DESC %in% Personal_Loan),as.character("Personal Loan"),
                                                                                           ifelse((Tradeline_data2$ACCOUNT_DESC %in% Short_Term_Secured_Loan),as.character("Short Term Secured Loan"),
                                                                                                  ifelse(is.na(Tradeline_data2$ACCOUNT_DESC),as.character("Other"),as.character(Tradeline_data2$ACCOUNT_DESC))))))))))
  
  
  
  
  Tradeline_data2$ReportingMemberShortName_derived <- ifelse((Tradeline_data2$ReportingMemberShortName %in% Internal),as.character("Internal"),as.character("External"))
  
  # Defining Loan status- Live/ Closed {
  
  # To make sure if closed date is populated and greater than Reference date then status of loan is closed
  
  Tradeline_data2$status_Loan <- ifelse((!is.na(Tradeline_data2$DATE_CLOSED) & Tradeline_data2$DATE_CLOSED<Tradeline_data2$Reference_date),"Closed",
                                        ifelse(!is.na(Tradeline_data2$DATE_CLOSED),"Live",
                                               ifelse(Tradeline_data2$ACCOUNT_DESC_derived!="Credit Card" & Tradeline_data2$Out_standing_Balance==0,"Closed",
                                                      ifelse(round(difftime(Tradeline_data2$Reference_date,Tradeline_data2$max_dt,units="days"))>366 & Tradeline_data2$Out_standing_Balance<5000,"Closed","Live"))))
  
  ## Change the status of the loan for missing to closed loans {
  
  Tradeline_data2$status_Loan[is.na(Tradeline_data2$status_Loan)]<-"Closed"
  table(Tradeline_data2$status_Loan)
  table(Tradeline_data2$status_Loan)/nrow(Tradeline_data2)
  #                                     }
  
  ## Creating variable for Loan amount, Amount Over due and amount paid off {
  Tradeline_data2$Amount<- ifelse((Tradeline_data2$ACCOUNT_DESC == "Credit Card") ,as.numeric(Tradeline_data2$Out_standing_Balance),
                                  as.numeric(Tradeline_data2$HighCreditSanctionedAmount))
  Tradeline_data2$Amount <- ifelse(is.na(Tradeline_data2$Amount),0,Tradeline_data2$Amount)
  
  Tradeline_data2$Over_due_amount <- ifelse(is.na(Tradeline_data2$Over_due_amount),0,Tradeline_data2$Over_due_amount)
  Tradeline_data2$Amt_paid_off  <- Tradeline_data2$Amount- Tradeline_data2$Out_standing_Balance
  #                                                                         }              
  
  ## Excluding CD and TW trades of clients- Specific- leave for now
  
  # data_Tradeline_data2 <- Tradeline_data2[!((Tradeline_data2$ReportingMemberShortName_derived == "Internal")&(Tradeline_data2$ACCOUNT_DESC %in% c("Two-wheeler Loan","Consumer Loan","Personal Loan"))),]
  # # data_Tradeline_data2 <- data_Tradeline_data2[data_Tradeline_data2$PaymentHistoryStartDate<="2018-03-01",]
  # data_Tradeline_data2 <- data.table(data_Tradeline_data2)
  
  months <- c(91,183,275,365,548,730,1095,1460,1825)
  Tradeline_data2$mob_bucket = ifelse(Tradeline_data2$diff_open_dt<=183,'mob_less6m',
                                      ifelse(Tradeline_data2$diff_open_dt<=365,'mob_6m_1y',
                                             ifelse(Tradeline_data2$diff_open_dt<=730,'mob_1y_2y','mob_more2y')))
  
  Treadline_train = Tradeline_data2[Tradeline_data2$val2==0,]
  avg_intRate_train_map = setDT(Treadline_train)[,list(
    avg_prod_mob_intrate_all = mean(interest_rate, na.rm = TRUE)
  ), by=c('ACCOUNT_DESC_derived',"mob_bucket")]
  
  Tradeline_data2= merge(x = Tradeline_data2, y = avg_intRate_train_map, all.x = TRUE, by.x =c('ACCOUNT_DESC_derived',"mob_bucket"), by.y = c('ACCOUNT_DESC_derived',"mob_bucket"))
  Tradeline_data2$ratio_interest_rate = Tradeline_data2$interest_rate/Tradeline_data2$avg_prod_mob_intrate_all
  data_tradeline_with_DPD_var <- Tradeline_data2
  return(data_tradeline_with_DPD_var)
  
}


Tradeline_data_with_DPD_var <- feature_engineering_DPD_variables(Tradeline_data2)

# ----------------------------------   3.  FEATURE ENGINEERING- LOAN TYPE BASED VARIABLES  ----------------------------------------

# Defining function to create these variables

Tradeline_data_with_DPD_var$score = 0
Tradeline_data_with_DPD_var$HighCreditSanctionedAmount = as.numeric(Tradeline_data_with_DPD_var$HighCreditSanctionedAmount)
Tradeline_data_with_DPD_var$WrittenOffAmountTotal = ifelse(Tradeline_data_with_DPD_var$past_due_days>180, Tradeline_data_with_DPD_var$Out_standing_Balance,0)
Tradeline_data_with_DPD_var$writeoff_status = ifelse(Tradeline_data_with_DPD_var$past_due_days>180, 1,0)
Tradeline_data_with_DPD_var$suit_filed_status=NA#no data assume 0
Tradeline_data_with_DPD_var$SettlementAmount=0 #no data assume 0

feature_engineering_loan_type_variables <- function(Data_tradeline){
  
  data_Tradeline_data2 <-data.table(Data_tradeline) #rename data_Tradeline_data2 later 
  
  
  TL_data_CRN <-data_Tradeline_data2[,j=list(score = max(score,0),
                                             num_Live = length(CRN[(status_Loan=="Live")]),
                                             Bureau_tenure_Other= max(diff_open_dt[(ACCOUNT_DESC_derived=="Other")],0),
                                             num_loans = .N,
                                             loan_amt_Individual = sum(Amount[(Ownership_type==1)],na.rm=TRUE),
                                             tsl_HL = min(diff_open_dt[(ACCOUNT_DESC_derived=="Housing Loan")],999999),
                                             tsl_live = min(diff_open_dt[status_Loan=="Live"],999999)
                                             
                                               ),by=CRN]
  
  TL_data_CRN[,Utilization:=ifelse((TL_data_CRN$Sanctioned_Amt_CC==0|is.na(TL_data_CRN$Sanctioned_Amt_CC)),0,TL_data_CRN$tot_outs_amt_CC/TL_data_CRN$Sanctioned_Amt_CC)]
  
  return (TL_data_CRN)
  
}



Tradeline_data_with_loan_type_var <- feature_engineering_loan_type_variables(Tradeline_data_with_DPD_var) 



#---------------------------------     4.  Creating the loan type variables at rolling time windows  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



feature_engineering_Loan_type_trend_variables <- function(data_Tradeline_data2){
  
  full_data2 <- data_Tradeline_data2
  
  #fina: make CRN level
  full_data2=data.frame(full_data2[,c('CRN')])
  full_data2=data.frame(full_data2[!duplicated(full_data2),])
  colnames(full_data2)[1] <- "CRN"
  
  
  months <- c(730,1095)
  month_names<-c("1m_to_2yr","2yr_to_3yr", "3yr_to_5yr")
  
  
  for (i in 1:length(months)){
    
    if(i==1){
      dataset <- subset(data_Tradeline_data2,(diff_open_dt<=months[i]))
      
    } else {
      dataset <- subset(data_Tradeline_data2,(diff_open_dt<=months[i]) & (diff_open_dt>months[i-1]) )
      
    }
    dataset <- subset(data_Tradeline_data2,(diff_open_dt<=months[i]) & (diff_open_dt>months[i-1]) )
    dataset<- data.table(dataset)
    Fact_Acct2 <- dataset[,j=list(
                                  Num_Live_last = length(CRN[(status_Loan=="Live")])
                                  
                                  
    ),by=CRN]
    
    colnames(Fact_Acct2) <- paste0(colnames(Fact_Acct2),"_",month_names[i])
    colnames(Fact_Acct2)[1] <- "CRN"
    
    full_data2 <- merge(full_data2,Fact_Acct2,by= "CRN",all.x = TRUE)
    
  }
  
  ## Missing value Treatment- REMOVE
  # is.na(full_data2) <- sapply(full_data2, is.infinite)
  # full_data2[is.na(full_data2)] <- 0
  
  data_Tradeline_data2<- full_data2
  
  return(data_Tradeline_data2)
  
}


Tradeline_data_with_loan_type_trend_var<- feature_engineering_Loan_type_trend_variables(Tradeline_data_with_DPD_var) #Not on CRN level, Tradeline level


#---------------------------------     5.  Creating the loan type variables at monthly level  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



# Defining function to create these variables

feature_engineering_loan_type_monthly_variables <- function(Data_tradeline){
  
  
  # Data_tradeline = Tradeline_data_with_DPD_var
  full_data_CRN <- Data_tradeline
  #fina: make CRN level
  full_data_CRN=data.frame(full_data_CRN[,c('CRN')])
  full_data_CRN=data.frame(full_data_CRN[!duplicated(full_data_CRN),])
  colnames(full_data_CRN)[1] <- "CRN"
  
  
  months <- c(31,92,183,274,365,548,730,1095,1460,1825)
  month_names<-c("1m","3m","6m","9m","1yr","18m","2yr","3yr","4yr","5yr")
  
  
  for (i in 1:length(months)){
    print(month_names[i])
    dataset <- subset(Data_tradeline,(diff_open_dt<=months[i]))
    dataset <- data.table(dataset)
    TL_CRN <- dataset[,j=list(num_trades_open_last = length(CRN),
                              Num_CC_last = length(CRN[ACCOUNT_DESC_derived=="Credit Card"]),
                              Num_BL_last = length(CRN[ACCOUNT_DESC_derived=="Business Loan"]),
                              loan_amt_last = max(sum(Amount[ACCOUNT_DESC_derived !="Credit Card"]),0),
                              Amt_BL_last = sum(Amount[ACCOUNT_DESC_derived=="Business Loan"],0),
                              Amt_Live_last = sum(Amount[(status_Loan=="Live")],0),
                              Amt_Individual_last = sum(Amount[(Ownership_type==1)],0),
                              Num_Other_last = length(CRN[ACCOUNT_DESC_derived=="Other"]),
                              Amt_sanct_CC_last = max(sum(Amount[ACCOUNT_DESC_derived=="Credit Card"]),0)
                              
                              ),by=CRN]
    
    colnames(TL_CRN) <- paste0(colnames(TL_CRN),"_",month_names[i])
    colnames(TL_CRN)[1] <- "CRN"
    
    full_data_CRN <- merge(full_data_CRN,TL_CRN,by= "CRN",all.x = TRUE)
    print(nrow(full_data_CRN))
    
    
  }
  
  ## Missing value Treatment
  # full_data_CRN[is.na(full_data_CRN)] <- 0
  
  ## To create monthly delinquency variables
  
  BUREAU_TL_data_CRN_level <- full_data_CRN # (same as Tradeline_data_with_DPD_var/ Data_tradeline)
  #months <- c(91,183,275,365,548,730,1095,1460,1825)
  months <- c(365,548)
  month_names<-c("1yr","18m")
  Data_tradeline <- data.table(Data_tradeline)
  for (i in 1:length(months)){
    print(month_names[i])
    delq_monthly_flags = Data_tradeline[,j=list(
      Num_delq_5_plus_last = length(CRN[(diff_delq_5_plus_dt< months[i])])
      
    ),by=CRN]
    
    colnames(delq_monthly_flags) <- paste0(colnames(delq_monthly_flags),"_",month_names[i])
    colnames(delq_monthly_flags)[1] <- "CRN"
    print(nrow(delq_monthly_flags))
    
    BUREAU_TL_data_CRN_level <- merge(BUREAU_TL_data_CRN_level,delq_monthly_flags,by= "CRN",all.x = TRUE)
    
  }
  
  print(nrow(BUREAU_TL_data_CRN_level))
  
  # is.na(BUREAU_TL_data_CRN_level) <- sapply(BUREAU_TL_data_CRN_level, is.infinite)
  # BUREAU_TL_data_CRN_level[is.na(BUREAU_TL_data_CRN_level)] <-0
  # saveRDS(BUREAU_TL_data_CRN_level,"FE Data/TL_MST.RDS")
  return (BUREAU_TL_data_CRN_level)
}

Tradeline_data_with_loan_type_monthly_var <- feature_engineering_loan_type_monthly_variables(Tradeline_data_with_DPD_var) #Trade level




# ----------------------------------   5.  FEATURE ENGINEERING- Interest Rate + Restructured Flag + BANK /NON BANK VARIABLES  ----------------------------------------



feature_engineering_new_variables <- function(Data_tradeline){
  
  data_Tradeline_data2 <-data.table(Data_tradeline) #rename data_Tradeline_data2 later 
  
  
  TL_data_CRN <-data_Tradeline_data2[,j=list(
    
    num_bank = length(CRN[(typeofcreditor=="BANKS")]),
    num_internal = length(CRN[(isInternalReportingMember==1)]),
    tot_outs_amt_external = sum(Out_standing_Balance[(isInternalReportingMember==0)],na.rm=TRUE),
    Amt_paid_off_bank = sum(Amt_paid_off[(typeofcreditor=="BANKS")],na.rm=TRUE),
    max_worstDPDBucket = max(worstDPDBucket,0),
    max_worstDPDBucket_CC = max(worstDPDBucket[(ACCOUNT_DESC_derived=="Credit Card")],0),
    Bureau_tenure_noBankBPR= max(diff_open_dt[(typeofcreditor=="Others")],0),
    tsl_bank = min(diff_open_dt[(typeofcreditor=="BANKS")],999999),
    tsl_noBankBPR = min(diff_open_dt[(typeofcreditor=="Others")],999999)
    
    
    
    
  ),by=CRN]
  
  return (TL_data_CRN)
  
}



Tradeline_data_with_new_var <- feature_engineering_new_variables(Tradeline_data_with_DPD_var) 


#Merge all these features later and bring them to CRN level


#write.csv(Tradeline_data_with_loan_type_monthly_var,"Tradeline_data_with_loan_type_monthly_var.csv", row.names = FALSE, na = "")
#saveRDS(Tradeline_data_with_loan_type_monthly_var, "Tradeline_data_with_loan_type_monthly_var.RDS")

all_aggregate_feature_merge <- merge(Tradeline_data_with_loan_type_var,Tradeline_data_with_loan_type_trend_var,by= "CRN",all.x = TRUE)
all_aggregate_feature_merge <- merge(all_aggregate_feature_merge,Tradeline_data_with_loan_type_monthly_var,by= "CRN",all.x = TRUE)
all_aggregate_feature_merge <- merge(all_aggregate_feature_merge,Tradeline_data_with_new_var,by= "CRN",all.x = TRUE)

#write.csv(all_aggregate_feature_merge,"Tradeline_all_aggregate_feature_merge_v3.csv", row.names = FALSE, na = "")
#saveRDS(all_aggregate_feature_merge, "Tradeline_all_aggregate_feature_merge_v3.RDS")

################################################################################
##########################      SCORING
################################################################################

#####     Model Wrapper Function #####
options(scipen=999)
Nmiss <- function(x)
{
  sum(as.numeric(x) %in% c(-999999,999999))
}

tradeline_data = all_aggregate_feature_merge

tradeline_data = as.data.frame(tradeline_data)

save(tradeline_data,file = "C:/Users/dewi.ismardi/Documents/DEWI/DIGITAL/LEAD BASE/PD FOR LEAD BASE/bureau data field/SLIK160920.Rdata")


var_imp <- xgb_importance$Feature

var_list_xgb <- model_xgb$feature_names

dd <- setdiff(var_list_xgb,var_imp)


dim(tradeline_data)

## Make dummy variables for 'non important' 136 variables in model
for (i in 1:length(dd)){
  tradeline_data[[dd[i]]] <- NA
}

## Converting Test and Train in XGB
dall2 <- xgb.DMatrix(data = data.matrix(tradeline_data[,var_list_xgb]))

xgb_bureau <- predict(model_xgb,dall2)

scored_data <- cbind(tradeline_data,xgb_bureau)


scored_data_bureau_final = scored_data[,c("CRN", "xgb_bureau")]

save(scored_data,file = "C:/Users/dewi.ismardi/Documents/DEWI/DIGITAL/LEAD BASE/PD FOR LEAD BASE/bureau data field/SLIK160920_score.Rdata")


summary(scored_data_bureau_final$xgb_bureau)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 0.03146 0.04078 0.05772 0.08431 0.10181 0.48163 
#write.csv(scored_fullData,paste(version,"/scored_fullData.csv", sep = ""))


 ##################### get demog score
library(RPostgreSQL)
demog_data = Demog_table

demog_data$education = "SMA"
demog_data$incoming_date = '2020-07-24'
demog_data$amenity_bank_3km = 25  ##data nnti dikasih ke IT terkait mapping zipcode
demog_data$dob = '1991-07-14'
#demog_data$dob2 = as.Date(demog_data$dob)
#demog_data$dob2 <- format(as.Date(demog_data$dob, format = "%Y-%m-%d"),"%Y-%m-%d")
#demog_data$diff_open_dt <- round(as.numeric(difftime(demog_data$incoming_date,demog_data$dob2,units = "years")))

demog_data$customer_age = as.period(interval(start = demog_data$dob, end = demog_data$incoming_date))$year                                    

demog_data$eduHighOrLess=0
demog_data[(demog_data[,'education']=='SD' | demog_data[,'education']=='SMP' | demog_data[,'education']=='SMA' | demog_data[,'education']=='TK' |demog_data[,'education']==''|demog_data[,'education']=='Others' ),c('eduHighOrLess')]=1


demog_data$male=0
demog_data[(demog_data[,'Gender']=='male') ,c('male')]=1

demog_data$family_house=0
demog_data[(demog_data[,'HomeOwnership']=='Own') ,c('family_house')]=1

#demog_data2 = subset(demog_data, select=c(IDNumber,ApplicationNumber, pefindoid, contract_sequence_id, date_perf, bucket, kolek, past_due_days,outstanding_amount_local_value, past_due_amount_local_value, interest_rate_local_value, Write_off_amt, Write_off_status))

#model predict
model_xgb = readRDS(file = "D:/OCBC NISP DEWI/Ticket 924186/Model PD Final/model_cust_VERSION_D2_11JUNE.RDS")

var_list_xgb1 <- model_xgb$feature_names

library("xgboost")
#predict the data
dall <- xgb.DMatrix(data = data.matrix(demog_data[,var_list_xgb1]))

xgb_demog <- predict(model_xgb,dall)


scored_data_demog <- cbind(demog_data,xgb_demog)

scored_data_demog_final = scored_data_demog[,c("ApplicationNumber","GUID","Name","MarketingCode","CustomerType","IDNumber", "CIF","xgb_demog")]

save(scored_data_demog_final,file = "D:/OCBC NISP DEWI/FOR API PD/scored_data_demog_final.Rdata")

#########
#calibration


load("D:/OCBC NISP DEWI/TES PEFINDO/DEWI SCRIPT/scored_data_bureau_final.Rdata")



############## NEED CHECK, COMBINE CAN USING NAMA+DOB+KTP

scored_data1 <- merge(scored_data_demog_final,scored_data_bureau_final,by.x = "IDNumber",by.y = "CRN",all.x=T)



### calibration
calibrated_constants <- readRDS("C:/Users/dewi.ismardi/Documents/DEWI/DIGITAL/PD MODEL/FINAL SCRIPT/Model PD Final/20200901_all_calibrated_constants.RDS")

calibrated_constants
#cal_cust         cal_bnk      cal_bureua         cal_net cal_bureau_slik 
#-0.007953087     0.084341943    -0.197682944     0.288260659     0.450090785 


scored_data1$logodd_demogs <- log(scored_data1$xgb_demog/(1-scored_data1$xgb_demog))
scored_data1$PD_demogs_temp <- scored_data1$logodd_demogs + calibrated_constants[1]
scored_data1$PD_demogs_calib = 1/(1+exp(-scored_data1$PD_demogs_temp))

#scored_data1$logodd_banking <- log(scored_data1$xgb_banking/(1-scored_data1$xgb_banking))
#scored_data1$PD_banking_temp <- scored_data1$logodd_banking + calibrated_constants[2]
#scored_data1$PD_banking_calib = 1/(1+exp(-scored_data1$PD_banking_temp))

#scored_data1$logodd_digital <- log(scored_data1$xgb_digital/(1-scored_data1$xgb_digital))
#scored_data1$PD_digital_temp <- scored_data1$logodd_digital + calibrated_constants[4]
#scored_data1$PD_digital_calib = 1/(1+exp(-scored_data1$PD_digital_temp))

scored_data$logodd_bureau <- log(scored_data$xgb_bureau/(1-scored_data$xgb_bureau))
scored_data$PD_bureau_temp <- scored_data$logodd_bureau + calibrated_constants[5]
scored_data$PD_bureau_calib = 1/(1+exp(-scored_data$PD_bureau_temp))

pd_database <- scored_data1[,c("ApplicationNumber","GUID","Name","MarketingCode","CustomerType","IDNumber", "CIF","PD_demogs_calib", "PD_bureau_calib")]

pd_database$PD_banking_calib = NA
pd_database$PD_digital_calib = NA


cal_pd_col_names = c("PD_demogs_calib","PD_banking_calib","PD_bureau_calib","PD_digital_calib")


### weight redistribution and final PD calculation
weight_matrix = c(0.1,0.45,0.35,0.1)

w = data.frame(matrix(nrow = nrow(pd_database), ncol = 4))
wgt_col_names = c("w1_cust","w2_bnk","w3_bureua","w4_net")
names(w) = wgt_col_names

for (i in 1:4){
  w[,i] <- weight_matrix[i]
}

# #Final wieghted PD after getting the right modular combination
pd_database$pd = rowSums(pd_database[,cal_pd_col_names]*w, na.rm = T)/rowSums((!is.na(
  pd_database[,cal_pd_col_names]))* w, na.rm = T)

save(pd_database,file = "D:/OCBC NISP DEWI/FOR API PD/pd_database.Rdata")

pd_database_to_los <- pd_database[,c("ApplicationNumber","GUID","Name","MarketingCode","CustomerType","IDNumber", "CIF","pd")]

 